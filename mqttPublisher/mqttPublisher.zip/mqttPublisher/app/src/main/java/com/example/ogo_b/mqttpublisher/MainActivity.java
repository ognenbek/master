package com.example.ogo_b.mqttpublisher;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.MqttClient;


import java.security.Security;
import java.util.Properties;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {


    {
        Security.addProvider(new org.spongycastle.jce.provider.BouncyCastleProvider());
    }


//    public static String Broker = "tcp://192.168.100.5:1883";
public static String Broker = "ssl://192.168.1.3:8883";
    private MqttAndroidClient clientSubscribe;
    private static String clientID;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        final Properties properties = new Properties();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final String clientId = MqttClient.generateClientId();
//        final String clientIdSubscriber = MqttClient.generateClientId();
        clientID = getString(R.string.clientId);
        final MqttAndroidClient client =
                new MqttAndroidClient(this.getApplicationContext(), Broker,
                        clientId);

        Button btnSendCredentials = findViewById(R.id.btnSendCredentials);
        btnSendCredentials.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("CREDENTIALS","Clicked");
                CredentialsPublisher.publish(client, getApplicationContext());
            }
        });

        Button btnSendTokenResourceServer = findViewById(R.id.btnSendTokenResourceServer);
        btnSendTokenResourceServer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TokenResourceServerPublisher.publish(client, getApplicationContext());
            }
        });

        final Timer timer = new Timer();

        Button btnSendData = findViewById(R.id.btnSendData);
        btnSendData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                timer.scheduleAtFixedRate(new TimerTask() {

                                              @Override
                                              public void run() {
                                                  // Magic here
                                                  DataPublisher.publish(client, getApplicationContext(), "09272018" + ";" + String.valueOf(new Random().nextInt(61) + 20));
                                              }
                                          },
                        0, 1000);
//                DataPublisher.publish(client, getApplicationContext(), "09272018" +  String.valueOf(new Random().nextInt(61) + 20));


            }
        });

        Button btnStopData = findViewById(R.id.btnStopSendData);
        btnStopData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                timer.cancel();
                DataPublisher.publish(client, getApplicationContext(), "stopStreaming");
            }
        });

    }
}
